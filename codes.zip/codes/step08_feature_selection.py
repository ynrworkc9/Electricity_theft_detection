"""
STEP 8: Feature Selection & Multicollinearity Analysis
Project: SGCC Electricity Theft Detection

Objective:
- Load 'train_features.csv' (strictly training split to prevent leakage).
- Perform multicollinearity analysis (Pearson correlation matrix).
- Identify redundant feature pairs (|r| > 0.90).
- Rank features by:
    1. Correlation with target 'FLAG'
    2. Random Forest feature importance (Gini impurity decrease)
- Save visual figures:
    - 'eda_plots/05_feature_correlation_heatmap.png'
    - 'eda_plots/06_feature_importance_ranking.png'
- Export 'selected_features.json' for model training in Steps 9 and 10.
"""

import os
import json
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.ensemble import RandomForestClassifier

def main():
    colab_dir = "/content/drive/MyDrive/Project"
    curr_dir = os.path.dirname(os.path.abspath(__file__))
    parent_dir = os.path.dirname(curr_dir)
    base_dir = colab_dir if os.path.exists(colab_dir) else (parent_dir if os.path.exists(os.path.join(parent_dir, 'data set.csv')) else curr_dir)
    train_feat_path = os.path.join(base_dir, "train_features.csv")
    plots_dir = os.path.join(base_dir, "eda_plots")
    selected_features_path = os.path.join(base_dir, "selected_features.json")

    os.makedirs(plots_dir, exist_ok=True)

    print("=" * 70)
    print("STEP 8: FEATURE SELECTION & MULTICOLLINEARITY ANALYSIS")
    print("=" * 70)

    if not os.path.exists(train_feat_path):
        raise FileNotFoundError(f"Missing train_features.csv at: {train_feat_path}. Run Step 7 first.")

    print(f"Loading training features: {train_feat_path}")
    df = pd.read_csv(train_feat_path)
    print(f"Shape: {df.shape[0]:,} consumers × {df.shape[1]} columns")

    id_col = "CONS_NO"
    label_col = "FLAG"
    feature_cols = [c for c in df.columns if c not in (id_col, label_col)]
    print(f"Number of engineered features: {len(feature_cols)}")

    # Sanity check for inf/nan
    X = df[feature_cols].copy()
    y = df[label_col].values

    # Clean any inf or nan if present
    X = X.replace([np.inf, -np.inf], np.nan)
    if X.isnull().sum().sum() > 0:
        print(f"Imputing {X.isnull().sum().sum()} occasional NaNs with column median...")
        X = X.fillna(X.median())

    # ──────────────────────────────────────────────────────────────────────────
    # 1. CORRELATION ANALYSIS & HEATMAP
    # ──────────────────────────────────────────────────────────────────────────
    print("\n[1/3] Computing Correlation Matrix...")
    corr_df = X.copy()
    corr_df["FLAG"] = y
    corr_matrix = corr_df.corr(method="pearson")

    # Plot Heatmap
    plt.figure(figsize=(18, 14))
    mask = np.triu(np.ones_like(corr_matrix, dtype=bool))
    cmap = sns.diverging_palette(230, 20, as_cmap=True)
    sns.heatmap(
        corr_matrix,
        mask=mask,
        cmap=cmap,
        vmax=1.0,
        vmin=-1.0,
        center=0,
        square=True,
        linewidths=0.5,
        cbar_kws={"shrink": 0.8},
        fmt=".2f",
        annot=True,
        annot_kws={"size": 7.5}
    )
    plt.title("Engineered Feature Correlation Matrix (Training Set)", fontsize=15, fontweight='bold', pad=15)
    plt.tight_layout()
    heatmap_path = os.path.join(plots_dir, "05_feature_correlation_heatmap.png")
    plt.savefig(heatmap_path, dpi=300)
    plt.close()
    print(f"Saved Correlation Heatmap: {heatmap_path}")

    # ──────────────────────────────────────────────────────────────────────────
    # 2. IDENTIFY REDUNDANT / COLLINEAR PAIRS (|r| > 0.90)
    # ──────────────────────────────────────────────────────────────────────────
    print("\n[2/3] Identifying Collinear Feature Pairs (|r| > 0.90)...")
    collinear_pairs = []
    feat_corr = corr_matrix.loc[feature_cols, feature_cols]
    for i in range(len(feature_cols)):
        for j in range(i + 1, len(feature_cols)):
            r = feat_corr.iloc[i, j]
            if abs(r) > 0.90:
                collinear_pairs.append((feature_cols[i], feature_cols[j], r))

    if collinear_pairs:
        print(f"Found {len(collinear_pairs)} highly collinear pairs (|r| > 0.90):")
        for f1, f2, r in collinear_pairs:
            print(f"  - {f1} <--> {f2} (r = {r:+.3f})")
    else:
        print("No pairs with |r| > 0.90 found.")

    # ──────────────────────────────────────────────────────────────────────────
    # 3. FEATURE IMPORTANCE RANKING (Random Forest)
    # ──────────────────────────────────────────────────────────────────────────
    print("\n[3/3] Ranking Feature Importance via Random Forest (class_weight='balanced')...")
    rf = RandomForestClassifier(
        n_estimators=100,
        max_depth=10,
        class_weight="balanced",
        random_state=42,
        n_jobs=-1
    )
    rf.fit(X, y)

    importances = pd.Series(rf.feature_importances_, index=feature_cols).sort_values(ascending=False)
    
    # Correlation with target
    target_corr = corr_matrix.loc[feature_cols, "FLAG"].abs().sort_values(ascending=False)

    ranking_df = pd.DataFrame({
        "RF_Importance": importances,
        "Abs_Target_Corr": target_corr[importances.index]
    })

    print("\nTop 15 Most Predictive Features:")
    print(ranking_df.head(15).to_string())

    # Plot Feature Importance
    plt.figure(figsize=(12, 7))
    palette = sns.color_palette("viridis", len(importances))
    sns.barplot(x=importances.values, y=importances.index, hue=importances.index, palette=palette, legend=False)
    plt.title("Feature Importance Ranking for Electricity Theft Detection (Random Forest)", fontsize=13, fontweight='bold', pad=12)
    plt.xlabel("Mean Impurity Decrease (Gini Importance)", fontsize=11)
    plt.ylabel("Engineered Feature", fontsize=11)
    plt.grid(axis='x', linestyle='--', alpha=0.6)
    plt.tight_layout()
    importance_path = os.path.join(plots_dir, "06_feature_importance_ranking.png")
    plt.savefig(importance_path, dpi=300)
    plt.close()
    print(f"Saved Feature Importance Plot: {importance_path}")

    # ──────────────────────────────────────────────────────────────────────────
    # 4. SELECT OPTIMAL SUBSET
    # ──────────────────────────────────────────────────────────────────────────
    # Redundant pairs handling: between (zero_days_count, zero_days_ratio) keep ratio;
    # between (std_consumption, var_consumption) keep std;
    # between (mean_consumption, median/mean_first_half) keep the one with higher importance.
    drop_redundant = []
    if "zero_days_count" in feature_cols and "zero_days_ratio" in feature_cols:
        drop_redundant.append("zero_days_count")
    if "var_consumption" in feature_cols and "std_consumption" in feature_cols:
        drop_redundant.append("var_consumption")

    selected_features = [f for f in importances.index if f not in drop_redundant]

    print(f"\nFinal Selected Feature Set ({len(selected_features)} features, redundant collinear metrics removed):")
    for idx, f in enumerate(selected_features, 1):
        print(f"  {idx:2d}. {f}")

    # Export selected features list
    with open(selected_features_path, "w") as fp:
        json.dump(selected_features, fp, indent=2)
    print(f"\nExported selected feature list to: {selected_features_path}")

    print("\n" + "=" * 70)
    print("STEP 8 COMPLETED SUCCESSFULLY")
    print("=" * 70)

if __name__ == "__main__":
    main()
