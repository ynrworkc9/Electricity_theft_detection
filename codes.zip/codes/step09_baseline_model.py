"""
STEP 9: Baseline Model Benchmark
Project: SGCC Electricity Theft Detection

Objective:
- Establish lower-bound performance benchmarks using simple, fast models.
- Compare:
    1. Dummy Classifier (Most Frequent -> always predicts Honest)
    2. Dummy Classifier (Stratified -> random guess proportional to class ratio)
    3. Logistic Regression (Standard, unweighted)
    4. Logistic Regression (Cost-sensitive, class_weight='balanced')
- Evaluate using Stratified 5-Fold Cross Validation strictly on the training set.
- Metrics recorded: PR-AUC (Average Precision), ROC-AUC, F1-Score, Recall, Precision, Accuracy.
- Outputs:
    - 'eda_plots/07_baseline_model_comparison.png'
    - 'baseline_results.json'
"""

import os
import json
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

from sklearn.dummy import DummyClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.preprocessing import StandardScaler
from sklearn.pipeline import Pipeline
from sklearn.model_selection import StratifiedKFold
from sklearn.metrics import (
    roc_auc_score,
    average_precision_score,
    f1_score,
    precision_score,
    recall_score,
    accuracy_score
)

def evaluate_cv(model, X, y, n_splits=5):
    """Run Stratified 5-Fold Cross Validation and record distribution of metrics."""
    skf = StratifiedKFold(n_splits=n_splits, shuffle=True, random_state=42)
    
    metrics = {
        "pr_auc": [],
        "roc_auc": [],
        "f1": [],
        "recall": [],
        "precision": [],
        "accuracy": []
    }

    for fold, (train_idx, val_idx) in enumerate(skf.split(X, y), 1):
        X_train_f, y_train_f = X.iloc[train_idx], y[train_idx]
        X_val_f, y_val_f = X.iloc[val_idx], y[val_idx]

        model.fit(X_train_f, y_train_f)
        
        # Probabilities for positive class (FLAG=1)
        if hasattr(model, "predict_proba"):
            y_proba = model.predict_proba(X_val_f)[:, 1]
        else:
            y_proba = model.decision_function(X_val_f)
            
        y_pred = model.predict(X_val_f)

        metrics["pr_auc"].append(average_precision_score(y_val_f, y_proba))
        metrics["roc_auc"].append(roc_auc_score(y_val_f, y_proba))
        metrics["f1"].append(f1_score(y_val_f, y_pred, zero_division=0))
        metrics["recall"].append(recall_score(y_val_f, y_pred, zero_division=0))
        metrics["precision"].append(precision_score(y_val_f, y_pred, zero_division=0))
        metrics["accuracy"].append(accuracy_score(y_val_f, y_pred))

    return {k: (np.mean(v), np.std(v)) for k, v in metrics.items()}

def main():
    colab_dir = "/content/drive/MyDrive/Project"
    curr_dir = os.path.dirname(os.path.abspath(__file__))
    parent_dir = os.path.dirname(curr_dir)
    base_dir = colab_dir if os.path.exists(colab_dir) else (parent_dir if os.path.exists(os.path.join(parent_dir, 'data set.csv')) else curr_dir)
    train_feat_path = os.path.join(base_dir, "train_features.csv")
    selected_features_path = os.path.join(base_dir, "selected_features.json")
    plots_dir = os.path.join(base_dir, "eda_plots")
    results_path = os.path.join(base_dir, "baseline_results.json")

    print("=" * 70)
    print("STEP 9: BASELINE MODEL BENCHMARK")
    print("=" * 70)

    # Load data and selected features
    df = pd.read_csv(train_feat_path)
    with open(selected_features_path, "r") as fp:
        features = json.load(fp)

    X = df[features].copy()
    y = df["FLAG"].values

    # Impute missing values with column median if any
    X = X.replace([np.inf, -np.inf], np.nan)
    if X.isnull().sum().sum() > 0:
        X = X.fillna(X.median())

    print(f"Dataset: {X.shape[0]:,} samples × {X.shape[1]} features")
    print(f"Target: Honest={np.sum(y==0):,} ({(y==0).mean()*100:.1f}%), Theft={np.sum(y==1):,} ({(y==1).mean()*100:.1f}%)")

    # Define baseline models
    models = {
        "Dummy (Most Frequent)": DummyClassifier(strategy="most_frequent"),
        "Dummy (Stratified)": DummyClassifier(strategy="stratified", random_state=42),
        "Logistic Regression (Standard)": Pipeline([
            ("scaler", StandardScaler()),
            ("clf", LogisticRegression(max_iter=1000, random_state=42))
        ]),
        "Logistic Regression (Balanced)": Pipeline([
            ("scaler", StandardScaler()),
            ("clf", LogisticRegression(class_weight="balanced", max_iter=1000, random_state=42))
        ])
    }

    results = {}
    print("\nRunning Stratified 5-Fold Cross Validation for each baseline...\n")

    for name, model in models.items():
        print(f"[*] Evaluating {name}...")
        scores = evaluate_cv(model, X, y, n_splits=5)
        results[name] = scores

    # Print summary table
    summary_rows = []
    for name, s in results.items():
        summary_rows.append({
            "Model": name,
            "PR-AUC": f"{s['pr_auc'][0]:.4f} ± {s['pr_auc'][1]:.4f}",
            "ROC-AUC": f"{s['roc_auc'][0]:.4f} ± {s['roc_auc'][1]:.4f}",
            "Recall (Theft)": f"{s['recall'][0]*100:.1f}%",
            "Precision": f"{s['precision'][0]*100:.1f}%",
            "F1-Score": f"{s['f1'][0]:.4f}",
            "Accuracy": f"{s['accuracy'][0]*100:.2f}%"
        })

    summary_df = pd.DataFrame(summary_rows)
    print("\n" + "=" * 95)
    print("BASELINE MODELS COMPARISON TABLE (5-Fold CV on Training Set)")
    print("=" * 95)
    print(summary_df.to_string(index=False))
    print("=" * 95)

    # Save to JSON
    json_results = {
        name: {metric: {"mean": val[0], "std": val[1]} for metric, val in metrics.items()}
        for name, metrics in results.items()
    }
    with open(results_path, "w") as fp:
        json.dump(json_results, fp, indent=2)
    print(f"\nSaved benchmark metrics to: {results_path}")

    # Plot comparison bar chart
    fig, axes = plt.subplots(1, 2, figsize=(14, 5.5))
    model_names = list(results.keys())
    pr_aucs = [results[m]["pr_auc"][0] for m in model_names]
    recalls = [results[m]["recall"][0] for m in model_names]
    f1s = [results[m]["f1"][0] for m in model_names]

    x = np.arange(len(model_names))
    width = 0.28

    axes[0].bar(x - width/2, pr_aucs, width, label='PR-AUC (Area Under PR Curve)', color='#2ca02c')
    axes[0].bar(x + width/2, [results[m]["roc_auc"][0] for m in model_names], width, label='ROC-AUC', color='#1f77b4')
    axes[0].set_ylabel("AUC Score")
    axes[0].set_title("Baseline Discrimination Capabilities (AUC)", fontsize=12, fontweight='bold')
    axes[0].set_xticks(x)
    axes[0].set_xticklabels(model_names, rotation=20, ha='right', fontsize=9)
    axes[0].legend()
    axes[0].grid(axis='y', linestyle='--', alpha=0.5)

    axes[1].bar(x - width/2, recalls, width, label='Recall (% Thieves Caught)', color='#d62728')
    axes[1].bar(x + width/2, f1s, width, label='F1-Score', color='#ff7f0e')
    axes[1].set_ylabel("Score")
    axes[1].set_title("Theft Detection Tradeoff (Recall vs F1)", fontsize=12, fontweight='bold')
    axes[1].set_xticks(x)
    axes[1].set_xticklabels(model_names, rotation=20, ha='right', fontsize=9)
    axes[1].legend()
    axes[1].grid(axis='y', linestyle='--', alpha=0.5)

    plt.tight_layout()
    chart_path = os.path.join(plots_dir, "07_baseline_model_comparison.png")
    plt.savefig(chart_path, dpi=300)
    plt.close()
    print(f"Saved Baseline Comparison Plot: {chart_path}")

    print("\n" + "=" * 70)
    print("STEP 9 BASELINE BENCHMARK COMPLETED SUCCESSFULLY")
    print("=" * 70)

if __name__ == "__main__":
    main()
