"""
Cleaning pipeline for the SGCC electricity theft dataset.
Input:  42,372 consumers × 1,036 columns (CONS_NO + 1,034 daily readings + FLAG)
Output: sgcc_cleaned.csv with outliers removed, missing values imputed, and negatives handled.
"""

import pandas as pd
import numpy as np

# ── STEP 1: LOAD DATA ────────────────────────────────────────────────────────
import os
colab_dir = "/content/drive/MyDrive/Project"
curr_dir = os.path.dirname(os.path.abspath(__file__))
parent_dir = os.path.dirname(curr_dir)
base_dir = colab_dir if os.path.exists(colab_dir) else (parent_dir if os.path.exists(os.path.join(parent_dir, 'data set.csv')) else curr_dir)
path = os.path.join(base_dir, "data set.csv")
df = pd.read_csv(path)

print("Shape:", df.shape)
print(df.dtypes.value_counts())
print(df.head())

# Separate structural columns from daily consumption readings
id_col = "CONS_NO"
label_col = "FLAG"
date_cols = [c for c in df.columns if c not in (id_col, label_col)]
print(f"Number of daily reading columns: {len(date_cols)}")

# Sanity checks
print("Duplicate consumer IDs:", df[id_col].duplicated().sum())
print("Label distribution:\n", df[label_col].value_counts(normalize=True))

# ── STEP 2: MISSING VALUE OVERVIEW ───────────────────────────────────────────
missing_per_row = df[date_cols].isnull().sum(axis=1)

print("Overall missing %:", df[date_cols].isnull().mean().mean() * 100)
print("Missing per consumer - describe():\n", missing_per_row.describe())

# Flag consumers with >60% of daily readings missing
high_missing_thresh = 0.6
high_missing_mask = (missing_per_row / len(date_cols)) > high_missing_thresh
print(f"Consumers with >{high_missing_thresh*100:.0f}% missing: {high_missing_mask.sum()}")

# Check if missingness correlates with theft label (bias indicator)
missing_by_label = df.groupby(label_col).apply(
    lambda g: g[date_cols].isnull().mean(axis=1).mean()
)
print("Average missing fraction by label:\n", missing_by_label)

# ── STEP 3: OUTLIER DETECTION (per consumer, before imputing) ────────────────
def flag_outliers_per_row(row_values, n_std=3):
    """Flag values beyond ±3 std from that consumer's own mean as outliers."""
    mean = np.nanmean(row_values)
    std = np.nanstd(row_values)
    if std == 0 or np.isnan(std):
        return np.zeros_like(row_values, dtype=bool)
    z = np.abs((row_values - mean) / std)
    return z > n_std

readings = df[date_cols].to_numpy(dtype=float)
outlier_mask = np.zeros_like(readings, dtype=bool)

for i in range(readings.shape[0]):
    outlier_mask[i, :] = flag_outliers_per_row(readings[i, :], n_std=3)

print("Total outlier cells flagged:", outlier_mask.sum())

# Flag negative readings as invalid (consumption cannot be negative)
negative_mask = readings < 0
print("Negative readings found:", negative_mask.sum())

# Replace outliers and negatives with NaN for imputation
readings[outlier_mask | negative_mask] = np.nan

# ── STEP 4: MISSING VALUE IMPUTATION (per consumer, row-wise) ────────────────
readings_df = pd.DataFrame(readings, columns=date_cols, index=df.index)

# Linear interpolation along time axis for each consumer
readings_df = readings_df.apply(
    lambda row: row.interpolate(method="linear", limit_direction="both"),
    axis=1,
)

# Fallback: fill any remaining NaNs with that consumer's own median
row_medians = readings_df.median(axis=1)
readings_df = readings_df.apply(lambda row: row.fillna(row_medians[row.name]), axis=1)

print("Remaining missing after interpolation + fallback:", readings_df.isnull().sum().sum())

# ── STEP 5: DROP CONSUMERS WITH ALL READINGS NaN ─────────────────────────────
# 5 consumers have all 1,034 readings completely empty — no imputation method
# can recover signal from an entirely empty series. Dropping them is the correct
# approach (Rahaman & Idris, 2026).
df_clean = df[[id_col, label_col]].copy()
df_clean = pd.concat([df_clean, readings_df], axis=1)

all_nan_mask = df_clean[date_cols].isnull().all(axis=1)
print(f"Consumers with ALL readings NaN (dropped): {all_nan_mask.sum()}")
df_clean = df_clean[~all_nan_mask].reset_index(drop=True)

print(f"Final shape: {df_clean.shape}")
print(f"Remaining NaNs: {df_clean.isnull().sum().sum()}")
print(f"Label distribution:\n{df_clean[label_col].value_counts()}")

# ── STEP 6: SAVE CLEANED DATA ────────────────────────────────────────────────
out_csv = os.path.join(base_dir, "sgcc_cleaned.csv")
df_clean.to_csv(out_csv, index=False)
print(f"Saved cleaned data to {out_csv}")
