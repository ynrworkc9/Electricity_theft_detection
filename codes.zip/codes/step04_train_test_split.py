"""
STEP 4: Train / Test Split (Stratified)
Project: SGCC Electricity Theft Detection

Objective:
- Load the cleaned SGCC dataset (sgcc_cleaned.csv).
- Perform a stratified 80/20 train/test split on 'FLAG' to preserve the ~8.5% theft ratio.
- Save 'train_data.csv' and 'test_data.csv' to strictly prevent data leakage in subsequent steps.
"""

import os
import pandas as pd
from sklearn.model_selection import train_test_split

def main():
    colab_dir = "/content/drive/MyDrive/Project"
    curr_dir = os.path.dirname(os.path.abspath(__file__))
    parent_dir = os.path.dirname(curr_dir)
    base_dir = colab_dir if os.path.exists(colab_dir) else (parent_dir if os.path.exists(os.path.join(parent_dir, 'data set.csv')) else curr_dir)
    cleaned_path = os.path.join(base_dir, "sgcc_cleaned.csv")
    train_path = os.path.join(base_dir, "train_data.csv")
    test_path = os.path.join(base_dir, "test_data.csv")

    print("=" * 70)
    print("STEP 4: STRATIFIED TRAIN / TEST SPLIT")
    print("=" * 70)
    
    if not os.path.exists(cleaned_path):
        raise FileNotFoundError(f"Cleaned dataset not found at: {cleaned_path}")

    print(f"Loading cleaned dataset: {cleaned_path}")
    df = pd.read_csv(cleaned_path)
    print(f"Loaded shape: {df.shape[0]:,} consumers × {df.shape[1]:,} columns")

    label_col = "FLAG"
    id_col = "CONS_NO"
    
    print("\nTotal Class Distribution:")
    counts = df[label_col].value_counts()
    print(f"  Honest (FLAG=0): {counts.get(0, 0):,} ({(df[label_col] == 0).mean()*100:.2f}%)")
    print(f"  Theft  (FLAG=1): {counts.get(1, 0):,} ({(df[label_col] == 1).mean()*100:.2f}%)")

    # Stratified 80/20 split
    print("\nPerforming Stratified 80/20 Split (Random State: 42)...")
    train_df, test_df = train_test_split(
        df,
        test_size=0.20,
        random_state=42,
        stratify=df[label_col]
    )

    print(f"\n[+] Training Set (80%): {train_df.shape[0]:,} consumers")
    print(f"    Honest (FLAG=0): {(train_df[label_col] == 0).sum():,} ({(train_df[label_col] == 0).mean()*100:.2f}%)")
    print(f"    Theft  (FLAG=1): {(train_df[label_col] == 1).sum():,} ({(train_df[label_col] == 1).mean()*100:.2f}%)")

    print(f"\n[+] Test Set (20% - Locked Benchmark): {test_df.shape[0]:,} consumers")
    print(f"    Honest (FLAG=0): {(test_df[label_col] == 0).sum():,} ({(test_df[label_col] == 0).mean()*100:.2f}%)")
    print(f"    Theft  (FLAG=1): {(test_df[label_col] == 1).sum():,} ({(test_df[label_col] == 1).mean()*100:.2f}%)")

    print(f"\nSaving training set to: {train_path}")
    train_df.to_csv(train_path, index=False)

    print(f"Saving test set to: {test_path}")
    test_df.to_csv(test_path, index=False)

    print("\n" + "=" * 70)
    print("STEP 4 COMPLETED: Train and Test splits are saved successfully.")
    print("=" * 70)

if __name__ == "__main__":
    main()
