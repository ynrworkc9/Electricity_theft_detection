"""
STEP 10: Multi-Family Model Training and Model Selection
Project: SGCC Electricity Theft Detection

Objective:
- Train and compare diverse, state-of-the-art non-linear ensemble families:
    1. Random Forest (Balanced)
    2. Extra Trees (Balanced)
    3. LightGBM (is_unbalance=True)
    4. XGBoost (scale_pos_weight tuned)
- Use Stratified 5-Fold Cross Validation strictly on the training set.
- Target Metric: PR-AUC (Average Precision) and F1-Score (handling severe class imbalance).
- Visualizations:
    - 'eda_plots/08_model_family_comparison.png': Multi-metric comparison bar chart
    - 'eda_plots/09_oof_pr_and_roc_curves.png': Out-of-fold PR and ROC Curves
- Outputs:
    - 'model_comparison_results.json'
    - 'best_model.joblib' (Winning model trained on full training set)
"""

import os
import json
import time
import joblib
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

from sklearn.model_selection import StratifiedKFold
from sklearn.ensemble import RandomForestClassifier, ExtraTreesClassifier
import lightgbm as lgb
import xgboost as xgb

from sklearn.metrics import (
    roc_auc_score,
    average_precision_score,
    f1_score,
    precision_score,
    recall_score,
    accuracy_score,
    precision_recall_curve,
    roc_curve
)

def evaluate_model_cv(name, model, X, y, skf):
    """Evaluate a model with Stratified K-Fold CV and gather out-of-fold probabilities."""
    print(f"[*] Training & evaluating: {name}...")
    t0 = time.time()
    
    oof_probas = np.zeros(len(y))
    oof_preds = np.zeros(len(y))

    pr_aucs = []
    roc_aucs = []
    recalls = []
    precisions = []
    f1s = []
    accuracies = []

    for fold, (train_idx, val_idx) in enumerate(skf.split(X, y), 1):
        X_tr, y_tr = X.iloc[train_idx], y[train_idx]
        X_va, y_va = X.iloc[val_idx], y[val_idx]

        model.fit(X_tr, y_tr)
        
        y_prob = model.predict_proba(X_va)[:, 1]
        y_pred = model.predict(X_va)

        oof_probas[val_idx] = y_prob
        oof_preds[val_idx] = y_pred

        pr_aucs.append(average_precision_score(y_va, y_prob))
        roc_aucs.append(roc_auc_score(y_va, y_prob))
        recalls.append(recall_score(y_va, y_pred, zero_division=0))
        precisions.append(precision_score(y_va, y_pred, zero_division=0))
        f1s.append(f1_score(y_va, y_pred, zero_division=0))
        accuracies.append(accuracy_score(y_va, y_pred))

    elapsed = time.time() - t0
    print(f"    Completed in {elapsed:.1f}s | PR-AUC: {np.mean(pr_aucs):.4f} | ROC-AUC: {np.mean(roc_aucs):.4f} | F1: {np.mean(f1s):.4f}")

    return {
        "metrics": {
            "pr_auc": (float(np.mean(pr_aucs)), float(np.std(pr_aucs))),
            "roc_auc": (float(np.mean(roc_aucs)), float(np.std(roc_aucs))),
            "recall": (float(np.mean(recalls)), float(np.std(recalls))),
            "precision": (float(np.mean(precisions)), float(np.std(precisions))),
            "f1": (float(np.mean(f1s)), float(np.std(f1s))),
            "accuracy": (float(np.mean(accuracies)), float(np.std(accuracies)))
        },
        "oof_probas": oof_probas,
        "oof_preds": oof_preds
    }

def main():
    colab_dir = "/content/drive/MyDrive/Project"
    curr_dir = os.path.dirname(os.path.abspath(__file__))
    parent_dir = os.path.dirname(curr_dir)
    base_dir = colab_dir if os.path.exists(colab_dir) else (parent_dir if os.path.exists(os.path.join(parent_dir, 'data set.csv')) else curr_dir)
    train_feat_path = os.path.join(base_dir, "train_features.csv")
    selected_features_path = os.path.join(base_dir, "selected_features.json")
    plots_dir = os.path.join(base_dir, "eda_plots")
    results_path = os.path.join(base_dir, "model_comparison_results.json")
    best_model_path = os.path.join(base_dir, "best_model.joblib")

    print("=" * 70)
    print("STEP 10: MULTI-FAMILY MODEL TRAINING & SELECTION")
    print("=" * 70)

    # 1. Load data
    df = pd.read_csv(train_feat_path)
    with open(selected_features_path, "r") as fp:
        features = json.load(fp)

    X = df[features].copy()
    y = df["FLAG"].values

    # Impute any missing value
    X = X.replace([np.inf, -np.inf], np.nan)
    if X.isnull().sum().sum() > 0:
        X = X.fillna(X.median())

    neg_count = np.sum(y == 0)
    pos_count = np.sum(y == 1)
    imbalance_ratio = neg_count / float(pos_count)
    print(f"Data: {X.shape[0]:,} samples × {X.shape[1]} features")
    print(f"Class ratio: {imbalance_ratio:.2f}:1 (Negative:Positive)")

    # 2. Define Model Families
    models = {
        "Random Forest (Balanced)": RandomForestClassifier(
            n_estimators=150,
            max_depth=12,
            min_samples_split=5,
            class_weight="balanced",
            random_state=42,
            n_jobs=-1
        ),
        "Extra Trees (Balanced)": ExtraTreesClassifier(
            n_estimators=150,
            max_depth=12,
            min_samples_split=5,
            class_weight="balanced",
            random_state=42,
            n_jobs=-1
        ),
        "LightGBM (Unbalanced)": lgb.LGBMClassifier(
            n_estimators=150,
            max_depth=6,
            learning_rate=0.06,
            is_unbalance=True,
            subsample=0.8,
            colsample_bytree=0.8,
            random_state=42,
            n_jobs=-1,
            verbose=-1
        ),
        "XGBoost (Weighted)": xgb.XGBClassifier(
            n_estimators=150,
            max_depth=6,
            learning_rate=0.06,
            scale_pos_weight=imbalance_ratio,
            subsample=0.8,
            colsample_bytree=0.8,
            eval_metric="logloss",
            random_state=42,
            n_jobs=-1
        )
    }

    # 3. Stratified 5-Fold Cross Validation
    skf = StratifiedKFold(n_splits=5, shuffle=True, random_state=42)
    eval_results = {}

    print("\nRunning Stratified 5-Fold Cross Validation across all model families...\n")
    for name, model in models.items():
        eval_results[name] = evaluate_model_cv(name, model, X, y, skf)

    # 4. Summary Table
    summary_data = []
    for name, res in eval_results.items():
        m = res["metrics"]
        summary_data.append({
            "Model Family": name,
            "PR-AUC (Target)": f"{m['pr_auc'][0]:.4f} ± {m['pr_auc'][1]:.4f}",
            "ROC-AUC": f"{m['roc_auc'][0]:.4f} ± {m['roc_auc'][1]:.4f}",
            "F1-Score": f"{m['f1'][0]:.4f} ± {m['f1'][1]:.4f}",
            "Recall (Theft)": f"{m['recall'][0]*100:.1f}%",
            "Precision": f"{m['precision'][0]*100:.1f}%",
            "Accuracy": f"{m['accuracy'][0]*100:.2f}%"
        })

    summary_df = pd.DataFrame(summary_data)
    print("\n" + "=" * 95)
    print("MODEL FAMILY BENCHMARK RESULTS (5-Fold Stratified CV on Training Set)")
    print("=" * 95)
    print(summary_df.to_string(index=False))
    print("=" * 95)

    # 5. Determine Winning Architecture based on PR-AUC & F1
    best_model_name = max(eval_results.keys(), key=lambda k: eval_results[k]["metrics"]["pr_auc"][0])
    best_pr_auc = eval_results[best_model_name]["metrics"]["pr_auc"][0]
    best_f1 = eval_results[best_model_name]["metrics"]["f1"][0]
    print(f"\n>>> WINNING MODEL: {best_model_name} (PR-AUC: {best_pr_auc:.4f}, F1: {best_f1:.4f})")

    # 6. Save Plot 08: Model Comparison Bar Chart
    fig, axes = plt.subplots(1, 2, figsize=(15, 5.5))
    names = list(eval_results.keys())
    pr_vals = [eval_results[n]["metrics"]["pr_auc"][0] for n in names]
    roc_vals = [eval_results[n]["metrics"]["roc_auc"][0] for n in names]
    recall_vals = [eval_results[n]["metrics"]["recall"][0] for n in names]
    f1_vals = [eval_results[n]["metrics"]["f1"][0] for n in names]

    x = np.arange(len(names))
    width = 0.35

    axes[0].bar(x - width/2, pr_vals, width, label='PR-AUC (Primary Metric)', color='#2ca02c')
    axes[0].bar(x + width/2, roc_vals, width, label='ROC-AUC', color='#1f77b4')
    axes[0].set_title("AUC Performance by Model Family", fontsize=12, fontweight='bold')
    axes[0].set_ylabel("Score")
    axes[0].set_xticks(x)
    axes[0].set_xticklabels(names, rotation=15, ha='right', fontsize=9)
    axes[0].legend()
    axes[0].grid(axis='y', linestyle='--', alpha=0.5)

    axes[1].bar(x - width/2, recall_vals, width, label='Recall (% Caught)', color='#d62728')
    axes[1].bar(x + width/2, f1_vals, width, label='F1-Score', color='#ff7f0e')
    axes[1].set_title("Detection Tradeoff: Recall vs F1-Score", fontsize=12, fontweight='bold')
    axes[1].set_ylabel("Score")
    axes[1].set_xticks(x)
    axes[1].set_xticklabels(names, rotation=15, ha='right', fontsize=9)
    axes[1].legend()
    axes[1].grid(axis='y', linestyle='--', alpha=0.5)

    plt.tight_layout()
    comp_plot_path = os.path.join(plots_dir, "08_model_family_comparison.png")
    plt.savefig(comp_plot_path, dpi=300)
    plt.close()
    print(f"Saved: {comp_plot_path}")

    # 7. Save Plot 09: Out-of-Fold PR & ROC Curves
    fig, axes = plt.subplots(1, 2, figsize=(14, 5.5))
    palette = ["#1f77b4", "#ff7f0e", "#2ca02c", "#d62728"]

    for idx, (name, res) in enumerate(eval_results.items()):
        prob = res["oof_probas"]
        prec, rec, _ = precision_recall_curve(y, prob)
        fpr, tpr, _ = roc_curve(y, prob)
        
        pr_score = res["metrics"]["pr_auc"][0]
        roc_score = res["metrics"]["roc_auc"][0]

        axes[0].plot(rec, prec, label=f"{name} (PR-AUC={pr_score:.3f})", color=palette[idx], linewidth=1.8)
        axes[1].plot(fpr, tpr, label=f"{name} (ROC-AUC={roc_score:.3f})", color=palette[idx], linewidth=1.8)

    # Baselines
    axes[0].axhline(y=pos_count/len(y), color='gray', linestyle='--', label=f'Random Chance ({pos_count/len(y):.2f})')
    axes[0].set_title("Precision-Recall (PR) Curves (Out-Of-Fold)", fontsize=12, fontweight='bold')
    axes[0].set_xlabel("Recall (% of Actual Thieves Detected)", fontsize=10)
    axes[0].set_ylabel("Precision (% True Frauds Among Flagged)", fontsize=10)
    axes[0].legend(loc="upper right", fontsize=8.5)
    axes[0].grid(True, linestyle='--', alpha=0.5)

    axes[1].plot([0, 1], [0, 1], color='gray', linestyle='--', label='Random Chance (0.50)')
    axes[1].set_title("Receiver Operating Characteristic (ROC) Curves", fontsize=12, fontweight='bold')
    axes[1].set_xlabel("False Positive Rate", fontsize=10)
    axes[1].set_ylabel("True Positive Rate", fontsize=10)
    axes[1].legend(loc="lower right", fontsize=8.5)
    axes[1].grid(True, linestyle='--', alpha=0.5)

    plt.tight_layout()
    curves_plot_path = os.path.join(plots_dir, "09_oof_pr_and_roc_curves.png")
    plt.savefig(curves_plot_path, dpi=300)
    plt.close()
    print(f"Saved: {curves_plot_path}")

    # 8. Train Best Model on full training dataset and save
    print(f"\nTraining winning model ({best_model_name}) on full training split (33,893 consumers)...")
    winning_model = models[best_model_name]
    winning_model.fit(X, y)

    joblib.dump({
        "model_name": best_model_name,
        "model": winning_model,
        "features": features,
        "training_samples": len(y),
        "cv_pr_auc": best_pr_auc,
        "cv_f1": best_f1
    }, best_model_path)
    print(f"Saved winning model artifact to: {best_model_path}")

    # Export results JSON
    serializable = {
        name: {
            metric: {"mean": val[0], "std": val[1]}
            for metric, val in res["metrics"].items()
        }
        for name, res in eval_results.items()
    }
    with open(results_path, "w") as fp:
        json.dump(serializable, fp, indent=2)
    print(f"Saved results summary to: {results_path}")

    print("\n" + "=" * 70)
    print("STEP 10 COMPLETED SUCCESSFULLY")
    print("=" * 70)

if __name__ == "__main__":
    main()
