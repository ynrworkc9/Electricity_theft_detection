"""
STEP 12: Final Model Evaluation on Untouched Test Set
Project: SGCC Electricity Theft Detection

Objective:
- Touch the locked test set (test_features.csv, 8,474 consumers) for the first and only time.
- Load the tuned model ('tuned_model.joblib').
- Evaluate performance metrics:
    1. Precision-Recall AUC (PR-AUC)
    2. Receiver Operating Characteristic AUC (ROC-AUC)
    3. Confusion Matrix (Default 0.50 threshold & F1-optimal threshold)
    4. Full Classification Report (Precision, Recall, F1, Specificity, Accuracy)
- Threshold Tuning Analysis for Utility Decision-Making:
    - Explore threshold spectrum [0.10, 0.90] to balance inspection budget vs. theft capture rate.
- Visualizations:
    - 'eda_plots/11_test_confusion_matrix.png'
    - 'eda_plots/12_test_pr_and_roc_curves.png'
    - 'eda_plots/13_threshold_tradeoff_curve.png'
- Output:
    - 'test_evaluation_results.json'
"""

import os
import json
import joblib
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

from sklearn.metrics import (
    average_precision_score,
    roc_auc_score,
    confusion_matrix,
    classification_report,
    precision_recall_curve,
    roc_curve,
    f1_score,
    precision_score,
    recall_score,
    accuracy_score
)

def main():
    colab_dir = "/content/drive/MyDrive/Project"
    curr_dir = os.path.dirname(os.path.abspath(__file__))
    parent_dir = os.path.dirname(curr_dir)
    base_dir = colab_dir if os.path.exists(colab_dir) else (parent_dir if os.path.exists(os.path.join(parent_dir, 'data set.csv')) else curr_dir)
    test_feat_path = os.path.join(base_dir, "test_features.csv")
    model_path = os.path.join(base_dir, "tuned_model.joblib")
    plots_dir = os.path.join(base_dir, "eda_plots")
    results_path = os.path.join(base_dir, "test_evaluation_results.json")

    os.makedirs(plots_dir, exist_ok=True)

    print("=" * 70)
    print("STEP 12: FINAL EVALUATION ON UNTOUCHED TEST SET")
    print("=" * 70)

    # 1. Load Model Artifact
    print(f"Loading tuned model artifact: {model_path}")
    artifact = joblib.load(model_path)
    model = artifact["model"]
    features = artifact["features"]
    print(f"Model loaded with {len(features)} selected features.")

    # 2. Load Test Features
    print(f"\nLoading untouched test dataset: {test_feat_path}")
    test_df = pd.read_csv(test_feat_path)
    print(f"Test size: {test_df.shape[0]:,} consumers × {test_df.shape[1]} columns")

    X_test = test_df[features].copy()
    y_test = test_df["FLAG"].values

    # Clean NaNs if present
    X_test = X_test.replace([np.inf, -np.inf], np.nan)
    if X_test.isnull().sum().sum() > 0:
        X_test = X_test.fillna(X_test.median())

    n_honest = np.sum(y_test == 0)
    n_theft = np.sum(y_test == 1)
    print(f"Ground Truth: Honest = {n_honest:,} ({n_honest/len(y_test)*100:.2f}%), Theft = {n_theft:,} ({n_theft/len(y_test)*100:.2f}%)")

    # 3. Generate Probabilities
    print("\nGenerating model prediction probabilities on test set...")
    y_prob = model.predict_proba(X_test)[:, 1]

    pr_auc = average_precision_score(y_test, y_prob)
    roc_auc = roc_auc_score(y_test, y_prob)

    print(f"\n[+] TEST PR-AUC (Average Precision) : {pr_auc:.4f}")
    print(f"[+] TEST ROC-AUC                   : {roc_auc:.4f}")

    # 4. Threshold Optimization Analysis
    precisions, recalls, thresholds = precision_recall_curve(y_test, y_prob)
    f1_scores = 2 * (precisions * recalls) / (precisions + recalls + 1e-8)
    best_idx = np.argmax(f1_scores)
    best_thresh = float(thresholds[best_idx]) if best_idx < len(thresholds) else 0.50
    best_f1 = float(f1_scores[best_idx])

    print(f"\n[+] Optimal F1 Threshold : {best_thresh:.3f} (Max F1: {best_f1:.4f})")

    # Evaluate at Default (0.50) and Optimal Thresholds
    y_pred_def = (y_prob >= 0.50).astype(int)
    y_pred_opt = (y_prob >= best_thresh).astype(int)

    cm_def = confusion_matrix(y_test, y_pred_def)
    cm_opt = confusion_matrix(y_test, y_pred_opt)

    print("\n" + "=" * 70)
    print("CLASSIFICATION REPORT (Default Threshold = 0.50)")
    print("=" * 70)
    print(classification_report(y_test, y_pred_def, target_names=["Honest (0)", "Theft (1)"], digits=4))

    print("\n" + "=" * 70)
    print(f"CLASSIFICATION REPORT (F1-Optimal Threshold = {best_thresh:.3f})")
    print("=" * 70)
    print(classification_report(y_test, y_pred_opt, target_names=["Honest (0)", "Theft (1)"], digits=4))

    # 5. Save Visualization 11: Confusion Matrices
    fig, axes = plt.subplots(1, 2, figsize=(13, 5))
    
    # Plot default CM
    sns.heatmap(cm_def, annot=True, fmt=',d', cmap='Blues', cbar=False, ax=axes[0],
                xticklabels=["Pred Honest", "Pred Theft"], yticklabels=["Actual Honest", "Actual Theft"],
                annot_kws={"size": 13, "weight": "bold"})
    axes[0].set_title(f"Confusion Matrix (Default Thresh = 0.50)\nRecall: {recall_score(y_test, y_pred_def)*100:.1f}%, Prec: {precision_score(y_test, y_pred_def)*100:.1f}%",
                      fontsize=12, fontweight='bold', pad=10)

    # Plot optimal CM
    sns.heatmap(cm_opt, annot=True, fmt=',d', cmap='Greens', cbar=False, ax=axes[1],
                xticklabels=["Pred Honest", "Pred Theft"], yticklabels=["Actual Honest", "Actual Theft"],
                annot_kws={"size": 13, "weight": "bold"})
    axes[1].set_title(f"Confusion Matrix (Optimal Thresh = {best_thresh:.3f})\nRecall: {recall_score(y_test, y_pred_opt)*100:.1f}%, Prec: {precision_score(y_test, y_pred_opt)*100:.1f}%",
                      fontsize=12, fontweight='bold', pad=10)

    plt.tight_layout()
    cm_plot_path = os.path.join(plots_dir, "11_test_confusion_matrix.png")
    plt.savefig(cm_plot_path, dpi=300)
    plt.close()
    print(f"Saved: {cm_plot_path}")

    # 6. Save Visualization 12: PR and ROC Curves
    fig, axes = plt.subplots(1, 2, figsize=(14, 5.5))
    
    # PR Curve
    axes[0].plot(recalls, precisions, color='#2ca02c', linewidth=2.5, label=f'Tuned LightGBM (PR-AUC = {pr_auc:.3f})')
    axes[0].axhline(y=n_theft/len(y_test), color='gray', linestyle='--', label=f'No Skill Baseline ({n_theft/len(y_test):.3f})')
    axes[0].scatter(recalls[best_idx], precisions[best_idx], color='red', s=70, zorder=5, label=f'Best F1 ({best_f1:.3f})')
    axes[0].set_title("Test Set: Precision-Recall Curve", fontsize=12, fontweight='bold')
    axes[0].set_xlabel("Recall (% of Thieves Caught)", fontsize=10)
    axes[0].set_ylabel("Precision (% True Frauds in Flags)", fontsize=10)
    axes[0].set_xlim(0, 1)
    axes[0].set_ylim(0, 1.02)
    axes[0].legend(loc="upper right")
    axes[0].grid(True, linestyle='--', alpha=0.5)

    # ROC Curve
    fpr, tpr, _ = roc_curve(y_test, y_prob)
    axes[1].plot(fpr, tpr, color='#1f77b4', linewidth=2.5, label=f'Tuned LightGBM (ROC-AUC = {roc_auc:.3f})')
    axes[1].plot([0, 1], [0, 1], color='gray', linestyle='--', label='Random Chance (0.50)')
    axes[1].set_title("Test Set: Receiver Operating Characteristic (ROC)", fontsize=12, fontweight='bold')
    axes[1].set_xlabel("False Positive Rate (False Alarms)", fontsize=10)
    axes[1].set_ylabel("True Positive Rate (Theft Detection Rate)", fontsize=10)
    axes[1].set_xlim(0, 1)
    axes[1].set_ylim(0, 1.02)
    axes[1].legend(loc="lower right")
    axes[1].grid(True, linestyle='--', alpha=0.5)

    plt.tight_layout()
    curves_plot_path = os.path.join(plots_dir, "12_test_pr_and_roc_curves.png")
    plt.savefig(curves_plot_path, dpi=300)
    plt.close()
    print(f"Saved: {curves_plot_path}")

    # 7. Save Visualization 13: Threshold Decision Curve
    thresh_scan = np.linspace(0.05, 0.95, 100)
    p_scan = []
    r_scan = []
    f1_scan = []

    for t in thresh_scan:
        preds = (y_prob >= t).astype(int)
        p_scan.append(precision_score(y_test, preds, zero_division=0))
        r_scan.append(recall_score(y_test, preds, zero_division=0))
        f1_scan.append(f1_score(y_test, preds, zero_division=0))

    fig, ax = plt.subplots(figsize=(11, 5.5))
    ax.plot(thresh_scan, p_scan, label="Precision (% Verified Frauds)", color="#1f77b4", linewidth=2.2)
    ax.plot(thresh_scan, r_scan, label="Recall (% Thieves Detected)", color="#d62728", linewidth=2.2)
    ax.plot(thresh_scan, f1_scan, label="F1-Score (Harmonic Mean)", color="#2ca02c", linewidth=2.2, linestyle='--')
    ax.axvline(x=best_thresh, color='purple', linestyle=':', linewidth=2, label=f'Optimal F1 Cutoff ({best_thresh:.2f})')
    ax.axvline(x=0.50, color='gray', linestyle='--', linewidth=1.5, label='Standard Cutoff (0.50)')

    ax.set_title("Operational Threshold Tuning: Inspection Cost vs. Fraud Recall", fontsize=13, fontweight='bold', pad=12)
    ax.set_xlabel("Classification Probability Threshold", fontsize=11)
    ax.set_ylabel("Metric Value", fontsize=11)
    ax.set_xlim(0.05, 0.95)
    ax.set_ylim(0, 1.02)
    ax.legend(frameon=True, facecolor='white', loc='center right')
    ax.grid(True, linestyle='--', alpha=0.5)

    plt.tight_layout()
    tradeoff_plot_path = os.path.join(plots_dir, "13_threshold_tradeoff_curve.png")
    plt.savefig(tradeoff_plot_path, dpi=300)
    plt.close()
    print(f"Saved: {tradeoff_plot_path}")

    # 8. Export Test Metrics JSON
    test_metrics = {
        "test_samples": len(y_test),
        "theft_cases": int(n_theft),
        "honest_cases": int(n_honest),
        "pr_auc": float(pr_auc),
        "roc_auc": float(roc_auc),
        "default_threshold": {
            "threshold": 0.50,
            "accuracy": float(accuracy_score(y_test, y_pred_def)),
            "precision": float(precision_score(y_test, y_pred_def)),
            "recall": float(recall_score(y_test, y_pred_def)),
            "f1_score": float(f1_score(y_test, y_pred_def)),
            "confusion_matrix": cm_def.tolist()
        },
        "optimal_threshold": {
            "threshold": best_thresh,
            "accuracy": float(accuracy_score(y_test, y_pred_opt)),
            "precision": float(precision_score(y_test, y_pred_opt)),
            "recall": float(recall_score(y_test, y_pred_opt)),
            "f1_score": float(f1_score(y_test, y_pred_opt)),
            "confusion_matrix": cm_opt.tolist()
        }
    }

    with open(results_path, "w") as fp:
        json.dump(test_metrics, fp, indent=2)
    print(f"\nSaved test evaluation metrics to: {results_path}")

    print("\n" + "=" * 70)
    print("STEP 12 FINAL EVALUATION COMPLETED SUCCESSFULLY")
    print("=" * 70)

if __name__ == "__main__":
    main()
