"""
STEP 7: Feature Engineering
Project: SGCC Electricity Theft Detection

Objective:
- Transform raw 1,034 daily time-series readings into domain-specific, high-signal tabular features.
- Applied identically to 'train_data.csv' and 'test_data.csv' (avoiding data leakage).
- Saves:
    1. 'train_features.csv' (~33,893 rows × ~30 engineered features + ID + FLAG)
    2. 'test_features.csv'  (~8,474 rows × ~30 engineered features + ID + FLAG)

Feature Categories:
1. Basic Statistical Moments: Mean, Median, Std, Var, Min, Max, Skewness, Kurtosis, IQR, CV.
2. Anomaly & Theft Indicators: Zero-consumption ratio, Peak-to-Average Ratio (PAR), Flatline count.
3. Trend & Drop Detection: First-half vs. Second-half consumption drop ratio (classic bypass indicator).
4. Volatility & Segment Dynamics: Monthly variance, max rolling drop, quarterly seasonality range.
"""

import os
import time
import numpy as np
import pandas as pd
from scipy import stats

def extract_features(df, date_cols, id_col="CONS_NO", label_col="FLAG"):
    """
    Vectorized extraction of statistical, behavioral, and drop-detection features
    from daily electricity consumption readings.
    """
    readings = df[date_cols].to_numpy(dtype=np.float64)
    n_samples, n_days = readings.shape
    eps = 1e-6

    print(f"  Extracting features from matrix: {n_samples:,} consumers × {n_days:,} days...")
    
    # ── 1. Statistical Moments ──
    mean_val = np.mean(readings, axis=1)
    median_val = np.median(readings, axis=1)
    std_val = np.std(readings, axis=1)
    var_val = np.var(readings, axis=1)
    min_val = np.min(readings, axis=1)
    max_val = np.max(readings, axis=1)
    
    q25 = np.percentile(readings, 25, axis=1)
    q75 = np.percentile(readings, 75, axis=1)
    iqr_val = q75 - q25
    cv_val = std_val / (mean_val + eps)  # Coefficient of Variation

    # Skewness & Kurtosis
    skew_val = stats.skew(readings, axis=1, nan_policy='omit')
    kurt_val = stats.kurtosis(readings, axis=1, nan_policy='omit')

    # ── 2. Anomaly & Theft Indicators ──
    zero_days = np.sum(readings <= 0.001, axis=1)
    zero_ratio = zero_days / float(n_days)
    par_val = max_val / (mean_val + eps)  # Peak-to-Average Ratio

    # Low and High consumption ratio relative to own average
    low_threshold = 0.1 * mean_val[:, None]
    high_threshold = 3.0 * mean_val[:, None]
    low_days_ratio = np.mean(readings < low_threshold, axis=1)
    high_days_ratio = np.mean(readings > high_threshold, axis=1)

    # ── 3. Temporal Trend & Drop Detection (Bypass Indicator) ──
    # Compare first half (e.g. days 0..516) to second half (days 517..1033)
    half_idx = n_days // 2
    first_half = readings[:, :half_idx]
    second_half = readings[:, half_idx:]

    mean_h1 = np.mean(first_half, axis=1)
    mean_h2 = np.mean(second_half, axis=1)
    std_h1 = np.std(first_half, axis=1)
    std_h2 = np.std(second_half, axis=1)

    # Drop ratio: Positive value indicates significant reduction in consumption in later periods
    consumption_drop_ratio = (mean_h1 - mean_h2) / (mean_h1 + eps)
    std_drop_ratio = (std_h1 - std_h2) / (std_h1 + eps)

    # ── 4. Segment & Rolling Window Dynamics ──
    # Split 1,034 days into 10 temporal chunks to evaluate trajectory shifts
    n_chunks = 10
    chunk_size = n_days // n_chunks
    chunk_means = np.zeros((n_samples, n_chunks))
    for c in range(n_chunks):
        c_slice = readings[:, c * chunk_size : (c + 1) * chunk_size]
        chunk_means[:, c] = np.mean(c_slice, axis=1)

    # Maximum drop between any two consecutive chunks
    chunk_diffs = chunk_means[:, :-1] - chunk_means[:, 1:]
    max_chunk_drop = np.max(chunk_diffs, axis=1)
    chunk_variance = np.var(chunk_means, axis=1)

    # ── 5. Assemble Features DataFrame ──
    features_dict = {
        id_col: df[id_col].values,
        label_col: df[label_col].values,
        
        # Statistical moments
        "mean_consumption": mean_val,
        "median_consumption": median_val,
        "std_consumption": std_val,
        "var_consumption": var_val,
        "min_consumption": min_val,
        "max_consumption": max_val,
        "iqr_consumption": iqr_val,
        "cv_consumption": cv_val,
        "skew_consumption": skew_val,
        "kurt_consumption": kurt_val,
        
        # Fraud & Anomaly metrics
        "zero_days_count": zero_days,
        "zero_days_ratio": zero_ratio,
        "peak_to_average_ratio": par_val,
        "low_consumption_ratio": low_days_ratio,
        "high_consumption_ratio": high_days_ratio,
        
        # Half-split trend & drop metrics
        "mean_first_half": mean_h1,
        "mean_second_half": mean_h2,
        "std_first_half": std_h1,
        "std_second_half": std_h2,
        "consumption_drop_ratio": consumption_drop_ratio,
        "std_drop_ratio": std_drop_ratio,
        
        # Segment dynamics
        "max_chunk_drop": max_chunk_drop,
        "chunk_variance": chunk_variance
    }

    feat_df = pd.DataFrame(features_dict)
    return feat_df

def main():
    colab_dir = "/content/drive/MyDrive/Project"
    curr_dir = os.path.dirname(os.path.abspath(__file__))
    parent_dir = os.path.dirname(curr_dir)
    base_dir = colab_dir if os.path.exists(colab_dir) else (parent_dir if os.path.exists(os.path.join(parent_dir, 'data set.csv')) else curr_dir)
    train_input = os.path.join(base_dir, "train_data.csv")
    test_input = os.path.join(base_dir, "test_data.csv")
    train_output = os.path.join(base_dir, "train_features.csv")
    test_output = os.path.join(base_dir, "test_features.csv")

    print("=" * 70)
    print("STEP 7: TIME-SERIES FEATURE ENGINEERING")
    print("=" * 70)

    for p in (train_input, test_input):
        if not os.path.exists(p):
            raise FileNotFoundError(f"Missing required file: {p}. Run Step 4 first.")

    t0 = time.time()
    print("1. Loading train_data.csv...")
    train_df = pd.read_csv(train_input)
    
    id_col = "CONS_NO"
    label_col = "FLAG"
    date_cols = [c for c in train_df.columns if c not in (id_col, label_col)]
    print(f"   Readings: {len(date_cols)} daily columns")

    print("\n2. Engineering features for TRAINING SET...")
    train_feat = extract_features(train_df, date_cols, id_col, label_col)
    print(f"   Generated train features: {train_feat.shape[0]:,} rows × {train_feat.shape[1]} columns")
    train_feat.to_csv(train_output, index=False)
    print(f"   Saved to: {train_output}")

    print("\n3. Loading test_data.csv...")
    test_df = pd.read_csv(test_input)

    print("\n4. Engineering features for TEST SET (identical pipeline)...")
    test_feat = extract_features(test_df, date_cols, id_col, label_col)
    print(f"   Generated test features: {test_feat.shape[0]:,} rows × {test_feat.shape[1]} columns")
    test_feat.to_csv(test_output, index=False)
    print(f"   Saved to: {test_output}")

    elapsed = time.time() - t0
    print(f"\nDone in {elapsed:.2f}s!")
    print("\n" + "=" * 70)
    print("FEATURE ENGINEERING COMPLETED")
    print("=" * 70)
    print(f"Extracted {train_feat.shape[1] - 2} features per consumer.")
    print("Sample feature columns:")
    for col in list(train_feat.columns[:8]) + ["..."] + list(train_feat.columns[-4:]):
        print(f"  - {col}")

if __name__ == "__main__":
    main()
