"""
STEP 6: Exploratory Data Analysis (EDA)
Project: SGCC Electricity Theft Detection

Objective:
- Load ONLY the training data (train_data.csv) to prevent data leakage.
- Generate domain-specific visualizations for electricity theft detection:
    1. 01_class_imbalance.png: Class breakdown (Honest vs. Theft)
    2. 02_aggregate_daily_consumption.png: 1,034-day aggregate consumption curves
    3. 03_individual_consumer_signatures.png: Individual time-series profiles
    4. 04_key_statistical_distributions.png: Statistical divergence (mean, std, zero-days, PAR)
- Output figures to 'eda_plots/' directory.
"""

import os
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

def main():
    colab_dir = "/content/drive/MyDrive/Project"
    curr_dir = os.path.dirname(os.path.abspath(__file__))
    parent_dir = os.path.dirname(curr_dir)
    base_dir = colab_dir if os.path.exists(colab_dir) else (parent_dir if os.path.exists(os.path.join(parent_dir, 'data set.csv')) else curr_dir)
    train_path = os.path.join(base_dir, "train_data.csv")
    plots_dir = os.path.join(base_dir, "eda_plots")

    os.makedirs(plots_dir, exist_ok=True)

    print("=" * 70)
    print("STEP 6: EXPLORATORY DATA ANALYSIS (EDA)")
    print("=" * 70)

    if not os.path.exists(train_path):
        raise FileNotFoundError(f"Training data not found at: {train_path}. Run Step 4 first.")

    print(f"Loading training data from: {train_path}")
    train_df = pd.read_csv(train_path)
    print(f"Training shape: {train_df.shape[0]:,} consumers × {train_df.shape[1]:,} columns")

    id_col = "CONS_NO"
    label_col = "FLAG"
    date_cols = [c for c in train_df.columns if c not in (id_col, label_col)]

    c_normal = "#1f77b4"
    c_theft = "#d62728"

    # ──────────────────────────────────────────────────────────────────────────
    # Plot 1: Class Imbalance
    # ──────────────────────────────────────────────────────────────────────────
    print("\n[1/4] Generating 01_class_imbalance.png...")
    fig, axes = plt.subplots(1, 2, figsize=(13, 5))

    sns.countplot(
        data=train_df,
        x=label_col,
        hue=label_col,
        palette=[c_normal, c_theft],
        legend=False,
        ax=axes[0]
    )
    axes[0].set_title("Training Set Class Counts", fontsize=13, fontweight='bold', pad=10)
    axes[0].set_xticks([0, 1])
    axes[0].set_xticklabels(["Honest Consumer (0)", "Theft / Fraud (1)"])
    axes[0].set_ylabel("Number of Consumers")
    axes[0].set_xlabel("")
    for p in axes[0].patches:
        axes[0].annotate(
            f'{int(p.get_height()):,}',
            (p.get_x() + p.get_width() / 2., p.get_height()),
            ha='center', va='bottom', fontsize=11, fontweight='bold',
            xytext=(0, 5), textcoords='offset points'
        )

    counts = train_df[label_col].value_counts().sort_index()
    wedges, texts, autotexts = axes[1].pie(
        counts,
        labels=["Honest (FLAG=0)", "Theft (FLAG=1)"],
        colors=[c_normal, c_theft],
        autopct='%1.1f%%',
        startangle=140,
        pctdistance=0.75,
        wedgeprops=dict(width=0.45, edgecolor='white', linewidth=2)
    )
    for at in autotexts:
        at.set_fontsize(11)
        at.set_fontweight('bold')
    axes[1].set_title("Severe Class Imbalance (~8.5% Theft)", fontsize=13, fontweight='bold', pad=10)

    plt.tight_layout()
    plot1_path = os.path.join(plots_dir, "01_class_imbalance.png")
    plt.savefig(plot1_path, dpi=300)
    plt.close()
    print(f"Saved: {plot1_path}")

    # ──────────────────────────────────────────────────────────────────────────
    # Plot 2: Aggregate Daily Consumption Timeline
    # ──────────────────────────────────────────────────────────────────────────
    print("\n[2/4] Generating 02_aggregate_daily_consumption.png...")
    train_normal_readings = train_df[train_df[label_col] == 0][date_cols].to_numpy(dtype=float)
    train_theft_readings = train_df[train_df[label_col] == 1][date_cols].to_numpy(dtype=float)

    mean_normal = np.mean(train_normal_readings, axis=0)
    mean_theft = np.mean(train_theft_readings, axis=0)
    days = np.arange(len(date_cols))

    fig, ax = plt.subplots(figsize=(14, 5.5))
    ax.plot(days, mean_normal, color=c_normal, alpha=0.25, label='Honest Daily Mean')
    ax.plot(days, pd.Series(mean_normal).rolling(30, min_periods=1).mean(),
            color=c_normal, linewidth=2.2, label='Honest 30-Day Moving Avg')
    ax.plot(days, mean_theft, color=c_theft, alpha=0.25, label='Theft Daily Mean')
    ax.plot(days, pd.Series(mean_theft).rolling(30, min_periods=1).mean(),
            color=c_theft, linewidth=2.2, label='Theft 30-Day Moving Avg')

    ax.set_title("Aggregate Daily Electricity Consumption Over 1,034 Days (Train Set)", fontsize=14, fontweight='bold', pad=12)
    ax.set_xlabel("Day Index (2014 to 2016)", fontsize=11)
    ax.set_ylabel("Average Consumption (kWh)", fontsize=11)
    ax.legend(frameon=True, facecolor='white', loc='upper right')
    ax.set_xlim(0, len(date_cols))

    plt.tight_layout()
    plot2_path = os.path.join(plots_dir, "02_aggregate_daily_consumption.png")
    plt.savefig(plot2_path, dpi=300)
    plt.close()
    print(f"Saved: {plot2_path}")

    # ──────────────────────────────────────────────────────────────────────────
    # Plot 3: Individual Consumer Signatures
    # ──────────────────────────────────────────────────────────────────────────
    print("\n[3/4] Generating 03_individual_consumer_signatures.png...")
    fig, axes = plt.subplots(3, 2, figsize=(15, 9), sharex=True)

    np.random.seed(42)
    normal_indices = np.random.choice(train_normal_readings.shape[0], 3, replace=False)
    theft_indices = np.random.choice(train_theft_readings.shape[0], 3, replace=False)

    for row in range(3):
        axes[row, 0].plot(days, train_normal_readings[normal_indices[row], :], color=c_normal, alpha=0.8, linewidth=0.9)
        axes[row, 0].set_ylabel(f"Consumer {row+1}\n(kWh)", fontsize=9)
        if row == 0:
            axes[row, 0].set_title("Honest Consumers (Natural Seasonality & Noise)", fontsize=12, fontweight='bold', pad=8)
        axes[row, 0].grid(True, linestyle='--', alpha=0.5)

        axes[row, 1].plot(days, train_theft_readings[theft_indices[row], :], color=c_theft, alpha=0.8, linewidth=0.9)
        axes[row, 1].set_ylabel(f"Theft User {row+1}\n(kWh)", fontsize=9)
        if row == 0:
            axes[row, 1].set_title("Theft Consumers (Sudden Drops, Flatlines, Low Variance)", fontsize=12, fontweight='bold', pad=8)
        axes[row, 1].grid(True, linestyle='--', alpha=0.5)

    axes[2, 0].set_xlabel("Day Index", fontsize=11)
    axes[2, 1].set_xlabel("Day Index", fontsize=11)

    plt.suptitle("Individual Consumption Profile Comparisons", fontsize=14, fontweight='bold', y=0.98)
    plt.tight_layout(rect=[0, 0.03, 1, 0.95])
    plot3_path = os.path.join(plots_dir, "03_individual_consumer_signatures.png")
    plt.savefig(plot3_path, dpi=300)
    plt.close()
    print(f"Saved: {plot3_path}")

    # ──────────────────────────────────────────────────────────────────────────
    # Plot 4: Statistical Metrics Distinctions
    # ──────────────────────────────────────────────────────────────────────────
    print("\n[4/4] Generating 04_key_statistical_distributions.png...")
    train_all_readings = train_df[date_cols].to_numpy(dtype=float)
    labels = train_df[label_col].to_numpy()

    mean_vals = np.mean(train_all_readings, axis=1)
    std_vals = np.std(train_all_readings, axis=1)
    zero_ratio = np.mean(train_all_readings <= 0.01, axis=1) * 100
    max_vals = np.max(train_all_readings, axis=1)
    par_vals = max_vals / (mean_vals + 1e-5)

    stats_df = pd.DataFrame({
        'FLAG': ['Honest (0)' if l == 0 else 'Theft (1)' for l in labels],
        'Mean_kWh': mean_vals,
        'Std_kWh': std_vals,
        'Zero_Days_Pct': zero_ratio,
        'PAR': np.clip(par_vals, 0, 50)
    })

    fig, axes = plt.subplots(2, 2, figsize=(14, 9))

    sns.boxplot(data=stats_df, x='FLAG', y='Mean_kWh', hue='FLAG', palette=[c_normal, c_theft], legend=False, ax=axes[0, 0], showfliers=False)
    axes[0, 0].set_title("Mean Daily Consumption", fontsize=12, fontweight='bold')
    axes[0, 0].set_ylabel("Mean Consumption (kWh)")
    axes[0, 0].set_xlabel("")

    sns.boxplot(data=stats_df, x='FLAG', y='Std_kWh', hue='FLAG', palette=[c_normal, c_theft], legend=False, ax=axes[0, 1], showfliers=False)
    axes[0, 1].set_title("Consumption Standard Deviation (Volatility)", fontsize=12, fontweight='bold')
    axes[0, 1].set_ylabel("Std Dev (kWh)")
    axes[0, 1].set_xlabel("")

    sns.boxplot(data=stats_df, x='FLAG', y='Zero_Days_Pct', hue='FLAG', palette=[c_normal, c_theft], legend=False, ax=axes[1, 0], showfliers=False)
    axes[1, 0].set_title("Percentage of Zero / Inactive Days", fontsize=12, fontweight='bold')
    axes[1, 0].set_ylabel("% Days with ~0 Consumption")
    axes[1, 0].set_xlabel("")

    sns.boxplot(data=stats_df, x='FLAG', y='PAR', hue='FLAG', palette=[c_normal, c_theft], legend=False, ax=axes[1, 1], showfliers=False)
    axes[1, 1].set_title("Peak-to-Average Ratio (PAR)", fontsize=12, fontweight='bold')
    axes[1, 1].set_ylabel("Peak / Mean Ratio")
    axes[1, 1].set_xlabel("")

    plt.suptitle("Statistical Feature Divergence: Honest vs. Fraudulent Users", fontsize=14, fontweight='bold', y=0.98)
    plt.tight_layout(rect=[0, 0.03, 1, 0.95])
    plot4_path = os.path.join(plots_dir, "04_key_statistical_distributions.png")
    plt.savefig(plot4_path, dpi=300)
    plt.close()
    print(f"Saved: {plot4_path}")

    print("\n" + "=" * 70)
    print("STEP 6 EDA COMPLETED: All plots saved to 'eda_plots/' directory.")
    print("=" * 70)

if __name__ == "__main__":
    main()
