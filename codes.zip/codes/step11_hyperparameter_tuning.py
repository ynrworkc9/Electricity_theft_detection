"""
STEP 11: Hyperparameter Tuning (LightGBM Optimization)
Project: SGCC Electricity Theft Detection

Objective:
- Fine-tune the winning model family (LightGBM) using RandomizedSearchCV.
- Cross-validation: Stratified 5-Fold CV on training split.
- Optimization Objective: PR-AUC ('average_precision' scorer) to maximize fraud detection under extreme imbalance.
- Search space: num_leaves, max_depth, learning_rate, n_estimators, min_child_samples, subsample, colsample_bytree, scale_pos_weight.
- Outputs:
    - 'best_hyperparameters.json'
    - 'tuned_model.joblib'
    - 'eda_plots/10_tuning_improvement.png'
"""

import os
import json
import time
import joblib
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import lightgbm as lgb

from sklearn.model_selection import StratifiedKFold, RandomizedSearchCV
from sklearn.metrics import (
    average_precision_score,
    roc_auc_score,
    f1_score,
    recall_score,
    precision_score,
    accuracy_score,
    make_scorer
)

def main():
    colab_dir = "/content/drive/MyDrive/Project"
    curr_dir = os.path.dirname(os.path.abspath(__file__))
    parent_dir = os.path.dirname(curr_dir)
    base_dir = colab_dir if os.path.exists(colab_dir) else (parent_dir if os.path.exists(os.path.join(parent_dir, 'data set.csv')) else curr_dir)
    train_feat_path = os.path.join(base_dir, "train_features.csv")
    selected_features_path = os.path.join(base_dir, "selected_features.json")
    plots_dir = os.path.join(base_dir, "eda_plots")
    best_params_path = os.path.join(base_dir, "best_hyperparameters.json")
    tuned_model_path = os.path.join(base_dir, "tuned_model.joblib")

    print("=" * 70)
    print("STEP 11: HYPERPARAMETER TUNING (LIGHTGBM OPTIMIZATION)")
    print("=" * 70)

    # 1. Load training features
    df = pd.read_csv(train_feat_path)
    with open(selected_features_path, "r") as fp:
        features = json.load(fp)

    X = df[features].copy()
    y = df["FLAG"].values

    # Clean NaNs/Infs
    X = X.replace([np.inf, -np.inf], np.nan)
    if X.isnull().sum().sum() > 0:
        X = X.fillna(X.median())

    print(f"Data: {X.shape[0]:,} samples × {X.shape[1]} features")
    imbalance_ratio = (y == 0).sum() / float((y == 1).sum())

    # 2. Define Parameter Distribution
    param_dist = {
        "n_estimators": [100, 150, 200, 250],
        "learning_rate": [0.03, 0.05, 0.07, 0.10],
        "num_leaves": [15, 25, 31, 45, 63],
        "max_depth": [4, 6, 8, 10, -1],
        "min_child_samples": [20, 40, 80, 150],
        "subsample": [0.7, 0.8, 0.9, 1.0],
        "colsample_bytree": [0.6, 0.7, 0.8, 0.9],
        "scale_pos_weight": [4.0, 7.0, 10.0, imbalance_ratio, 13.0]
    }

    base_estimator = lgb.LGBMClassifier(
        random_state=42,
        n_jobs=-1,
        verbose=-1
    )

    skf = StratifiedKFold(n_splits=5, shuffle=True, random_state=42)
    pr_auc_scorer = make_scorer(average_precision_score, response_method='predict_proba')

    print("\nConfiguring RandomizedSearchCV (20 candidate iterations with 5-Fold Stratified CV)...")
    search = RandomizedSearchCV(
        estimator=base_estimator,
        param_distributions=param_dist,
        n_iter=20,
        scoring=pr_auc_scorer,
        cv=skf,
        verbose=1,
        random_state=42,
        n_jobs=1
    )

    t0 = time.time()
    search.fit(X, y)
    elapsed = time.time() - t0

    print(f"\nOptimization completed in {elapsed:.1f}s!")
    print(f"Best Mean CV PR-AUC: {search.best_score_:.4f}")
    print("\nBest Hyperparameters Found:")
    for k, v in search.best_params_.items():
        print(f"  - {k}: {v}")

    # 3. Comprehensive Evaluation of Best Tuned Model across 5 Folds
    best_tuned_clf = lgb.LGBMClassifier(
        **search.best_params_,
        random_state=42,
        n_jobs=-1,
        verbose=-1
    )

    tuned_metrics = {"pr_auc": [], "roc_auc": [], "f1": [], "recall": [], "precision": [], "accuracy": []}
    default_metrics = {"pr_auc": [], "roc_auc": [], "f1": [], "recall": [], "precision": [], "accuracy": []}

    default_clf = lgb.LGBMClassifier(is_unbalance=True, random_state=42, n_jobs=-1, verbose=-1)

    print("\nComparing Default LightGBM vs. Tuned LightGBM across all 5 folds...")
    for fold, (train_idx, val_idx) in enumerate(skf.split(X, y), 1):
        X_tr, y_tr = X.iloc[train_idx], y[train_idx]
        X_va, y_va = X.iloc[val_idx], y[val_idx]

        # Tuned
        best_tuned_clf.fit(X_tr, y_tr)
        p_tuned = best_tuned_clf.predict_proba(X_va)[:, 1]
        pred_tuned = best_tuned_clf.predict(X_va)

        tuned_metrics["pr_auc"].append(average_precision_score(y_va, p_tuned))
        tuned_metrics["roc_auc"].append(roc_auc_score(y_va, p_tuned))
        tuned_metrics["f1"].append(f1_score(y_va, pred_tuned, zero_division=0))
        tuned_metrics["recall"].append(recall_score(y_va, pred_tuned, zero_division=0))
        tuned_metrics["precision"].append(precision_score(y_va, pred_tuned, zero_division=0))
        tuned_metrics["accuracy"].append(accuracy_score(y_va, pred_tuned))

        # Default
        default_clf.fit(X_tr, y_tr)
        p_def = default_clf.predict_proba(X_va)[:, 1]
        pred_def = default_clf.predict(X_va)

        default_metrics["pr_auc"].append(average_precision_score(y_va, p_def))
        default_metrics["roc_auc"].append(roc_auc_score(y_va, p_def))
        default_metrics["f1"].append(f1_score(y_va, pred_def, zero_division=0))
        default_metrics["recall"].append(recall_score(y_va, pred_def, zero_division=0))
        default_metrics["precision"].append(precision_score(y_va, pred_def, zero_division=0))
        default_metrics["accuracy"].append(accuracy_score(y_va, pred_def))

    # Print comparison table
    comparison_table = [
        {
            "Configuration": "Default LightGBM",
            "PR-AUC": f"{np.mean(default_metrics['pr_auc']):.4f} ± {np.std(default_metrics['pr_auc']):.4f}",
            "ROC-AUC": f"{np.mean(default_metrics['roc_auc']):.4f} ± {np.std(default_metrics['roc_auc']):.4f}",
            "F1-Score": f"{np.mean(default_metrics['f1']):.4f}",
            "Recall (Theft)": f"{np.mean(default_metrics['recall'])*100:.1f}%",
            "Precision": f"{np.mean(default_metrics['precision'])*100:.1f}%",
            "Accuracy": f"{np.mean(default_metrics['accuracy'])*100:.2f}%"
        },
        {
            "Configuration": "Tuned LightGBM",
            "PR-AUC": f"{np.mean(tuned_metrics['pr_auc']):.4f} ± {np.std(tuned_metrics['pr_auc']):.4f}",
            "ROC-AUC": f"{np.mean(tuned_metrics['roc_auc']):.4f} ± {np.std(tuned_metrics['roc_auc']):.4f}",
            "F1-Score": f"{np.mean(tuned_metrics['f1']):.4f}",
            "Recall (Theft)": f"{np.mean(tuned_metrics['recall'])*100:.1f}%",
            "Precision": f"{np.mean(tuned_metrics['precision'])*100:.1f}%",
            "Accuracy": f"{np.mean(tuned_metrics['accuracy'])*100:.2f}%"
        }
    ]

    print("\n" + "=" * 95)
    print("HYPERPARAMETER TUNING IMPACT COMPARISON (5-Fold CV on Training Set)")
    print("=" * 95)
    print(pd.DataFrame(comparison_table).to_string(index=False))
    print("=" * 95)

    # 4. Save visualization: 10_tuning_improvement.png
    fig, ax = plt.subplots(figsize=(10, 5.5))
    metrics_names = ["PR-AUC", "ROC-AUC", "F1-Score", "Recall", "Precision"]
    def_vals = [
        np.mean(default_metrics['pr_auc']),
        np.mean(default_metrics['roc_auc']),
        np.mean(default_metrics['f1']),
        np.mean(default_metrics['recall']),
        np.mean(default_metrics['precision'])
    ]
    tuned_vals = [
        np.mean(tuned_metrics['pr_auc']),
        np.mean(tuned_metrics['roc_auc']),
        np.mean(tuned_metrics['f1']),
        np.mean(tuned_metrics['recall']),
        np.mean(tuned_metrics['precision'])
    ]

    x = np.arange(len(metrics_names))
    width = 0.35

    ax.bar(x - width/2, def_vals, width, label='Default LightGBM', color='#7f7f7f', alpha=0.85)
    ax.bar(x + width/2, tuned_vals, width, label='Tuned LightGBM', color='#2ca02c', alpha=0.95)
    ax.set_title("Performance Gain from Hyperparameter Tuning (5-Fold CV)", fontsize=13, fontweight='bold', pad=12)
    ax.set_ylabel("Score", fontsize=11)
    ax.set_xticks(x)
    ax.set_xticklabels(metrics_names, fontsize=10)
    ax.legend(frameon=True, facecolor='white')
    ax.grid(axis='y', linestyle='--', alpha=0.5)

    for i in range(len(metrics_names)):
        ax.annotate(f"{def_vals[i]:.3f}", (x[i] - width/2, def_vals[i]), ha='center', va='bottom', fontsize=9, xytext=(0, 3), textcoords='offset points')
        ax.annotate(f"{tuned_vals[i]:.3f}", (x[i] + width/2, tuned_vals[i]), ha='center', va='bottom', fontsize=9, fontweight='bold', xytext=(0, 3), textcoords='offset points')

    plt.tight_layout()
    plot_path = os.path.join(plots_dir, "10_tuning_improvement.png")
    plt.savefig(plot_path, dpi=300)
    plt.close()
    print(f"Saved: {plot_path}")

    # 5. Fit Tuned Model on full training set and export artifacts
    print("\nFitting final tuned model on full training split (33,893 consumers)...")
    final_tuned_model = lgb.LGBMClassifier(
        **search.best_params_,
        random_state=42,
        n_jobs=-1,
        verbose=-1
    )
    final_tuned_model.fit(X, y)

    # Save joblib model
    joblib.dump({
        "model": final_tuned_model,
        "features": features,
        "best_params": search.best_params_,
        "cv_pr_auc": search.best_score_
    }, tuned_model_path)
    print(f"Saved tuned model to: {tuned_model_path}")

    # Save hyperparameters JSON
    with open(best_params_path, "w") as fp:
        json.dump(search.best_params_, fp, indent=2)
    print(f"Saved hyperparameters to: {best_params_path}")

    print("\n" + "=" * 70)
    print("STEP 11 COMPLETED SUCCESSFULLY")
    print("=" * 70)

if __name__ == "__main__":
    main()
